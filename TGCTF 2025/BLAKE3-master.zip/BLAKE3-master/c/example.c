#include "blake3.h"
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

//#include "blake3.c"
//#include "blake3_dispatch.c"
//#include "blake3_portable.c"
//#include "blake3_sse2_x86-64_unix.S"
//#include "blake3_sse41_x86-64_unix.S"
//#include "blake3_avx2_x86-64_unix.S"
//#include "blake3_avx512_x86-64_unix.S"
//gcc -O3 -o example example.c blake3.c blake3_dispatch.c blake3_portable.c blake3_sse2_x86-64_unix.S blake3_sse41_x86-64_unix.S blake3_avx2_x86-64_unix.S blake3_avx512_x86-64_unix.S


int main(void) {
    // 初始化哈希器。
    blake3_hasher hasher;
    blake3_hasher_init(&hasher);

    printf("111\n");

    // 从 stdin 读取输入字节。
    unsigned char buf[65536];
    while (1) {
        ssize_t n = read(STDIN_FILENO, buf, sizeof(buf));
        if (n > 0) {
            blake3_hasher_update(&hasher, buf, n);
            printf("222\n");
            printf("读取了 %zd 字节\n", n);  // 调试信息
        } else if (n == 0) {
            printf("333\n");
            break; // 文件结束
        } else {
            printf("444\n");
            fprintf(stderr, "读取失败: %s\n", strerror(errno));
            exit(1);
        }
    }

    // 完成哈希计算。BLAKE3_OUT_LEN 是默认的输出长度，32 字节。
    uint8_t output[BLAKE3_OUT_LEN];

    printf("准备进行哈希计算...\n");

    // 计算哈希
    blake3_hasher_finalize(&hasher, output, BLAKE3_OUT_LEN);

    printf("555\n");

    // 检查哈希值是否被成功填充
    int all_zero = 1;
    for (size_t i = 0; i < BLAKE3_OUT_LEN; i++) {
        if (output[i] != 0) {
            all_zero = 0;
            break;
        }
    }

    if (all_zero) {
        printf("警告：哈希值未被正确生成。\n");
    } else {
        // 打印哈希值的十六进制表示。
        printf("输出哈希值:\n");
        for (size_t i = 0; i < BLAKE3_OUT_LEN; i++) {
            printf("%02x", output[i]);
        }
        printf("\n");
    }

    // 将输出重定向到文件以便检查
    FILE *output_file = fopen("output.txt", "wb");
    if (output_file) {
        fwrite(output, sizeof(uint8_t), BLAKE3_OUT_LEN, output_file);
        fclose(output_file);
        printf("哈希值已写入 output.txt\n");
    } else {
        fprintf(stderr, "无法写入 output.txt: %s\n", strerror(errno));
    }

    return 0;
}